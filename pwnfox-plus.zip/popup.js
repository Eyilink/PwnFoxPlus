'use strict';

const CONTAINERS = [
  { colorName: 'red',       color: '#ff613d', name: 'Red'       },
  { colorName: 'orange',    color: '#ff9f00', name: 'Orange'    },
  { colorName: 'yellow',    color: '#ffcb00', name: 'Yellow'    },
  { colorName: 'green',     color: '#51cd00', name: 'Green'     },
  { colorName: 'turquoise', color: '#00c79a', name: 'Turquoise' },
  { colorName: 'blue',      color: '#37adff', name: 'Blue'      },
  { colorName: 'purple',    color: '#af51f5', name: 'Purple'    },
  { colorName: 'pink',      color: '#ff4bda', name: 'Pink'      },
];

const BADGE_TEXT = {
  red:'#fff', orange:'#fff', yellow:'#6b4e00', green:'#fff',
  turquoise:'#fff', blue:'#fff', purple:'#fff', pink:'#fff',
};

const DEFAULT_SETTINGS = {
  proxyEnabled: true,
  proxifyContainersOnly: true,
  addContainerHeader: true,
  removeSecurityHeaders: false,
  containerLabels: {},
  cookieStoreIds: {},
};

let settings = { ...DEFAULT_SETTINGS, containerLabels: {}, cookieStoreIds: {} };
let editingColorName = null;

function loadSettings(cb) {
  browser.storage.local.get(DEFAULT_SETTINGS, (data) => {
    settings = {
      ...DEFAULT_SETTINGS, ...data,
      containerLabels: data.containerLabels || {},
      cookieStoreIds:  data.cookieStoreIds  || {},
    };
    cb();
  });
}

function saveSettings() {
  browser.storage.local.set(settings);
  browser.runtime.sendMessage({ type: 'settingsChanged', settings }).catch(() => {});
}

// ── Get or create the persistent identity for a color slot ─────────────────
// Returns a Promise<cookieStoreId>
function getOrCreateIdentity(c) {
  const storedId = settings.cookieStoreIds[c.colorName];
  const label    = settings.containerLabels[c.colorName] || c.name;

  if (storedId) {
    return browser.contextualIdentities.get(storedId)
      .then(identity => identity.cookieStoreId)
      .catch(() => createIdentity(c, label)); // was deleted, recreate
  }
  return createIdentity(c, label);
}

function createIdentity(c, name) {
  return browser.contextualIdentities.create({
    name:  name,
    color: c.colorName,
    icon:  'circle',
  }).then(identity => {
    settings.cookieStoreIds[c.colorName] = identity.cookieStoreId;
    saveSettings();
    return identity.cookieStoreId;
  });
}

// ── When label is saved, rename the existing identity ─────────────────────
function applyLabelToIdentity(c, label) {
  const storedId = settings.cookieStoreIds[c.colorName];
  const newName  = label || c.name;

  if (storedId) {
    // Update the name Firefox shows next to the circle in the URL bar
    browser.contextualIdentities.update(storedId, { name: newName }).catch(() => {
      // Identity gone — will be recreated next time user opens a tab
      delete settings.cookieStoreIds[c.colorName];
      saveSettings();
    });
  }
  // If no identity yet, it will be created with the right name on first tab open
}

// ── Toggles ────────────────────────────────────────────────────────────────
function renderToggles() {
  document.querySelectorAll('.toggle[data-key]').forEach(el => {
    const key = el.dataset.key;
    el.classList.toggle('on', !!settings[key]);
    el.onclick = () => {
      settings[key] = !settings[key];
      el.classList.toggle('on', settings[key]);
      saveSettings();
    };
  });
}

// ── Grid ───────────────────────────────────────────────────────────────────
function renderGrid() {
  const grid = document.getElementById('containerGrid');
  grid.innerHTML = '';
  CONTAINERS.forEach(c => {
    const label = settings.containerLabels[c.colorName] || '';
    const btn = document.createElement('div');
    btn.className = 'c-btn';

    const dot = document.createElement('div');
    dot.className = 'c-dot';
    dot.style.background = c.color;
    btn.appendChild(dot);

    if (label) {
      const badge = document.createElement('div');
      badge.className = 'c-badge';
      badge.style.background = c.color;
      badge.style.color = BADGE_TEXT[c.colorName] || '#fff';
      badge.style.display = 'block';
      badge.textContent = label;
      btn.appendChild(badge);
    } else {
      const nameEl = document.createElement('div');
      nameEl.className = 'c-name';
      nameEl.textContent = c.name;
      btn.appendChild(nameEl);
    }

    const editBtn = document.createElement('div');
    editBtn.className = 'c-edit';
    editBtn.title = 'Edit label';
    editBtn.innerHTML = '<svg viewBox="0 0 10 10" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M7 1.5 8.5 3l-5 5H2V6.5l5-5z"/></svg>';
    editBtn.addEventListener('click', (e) => { e.stopPropagation(); openModal(c); });
    btn.appendChild(editBtn);

    btn.addEventListener('click', () => openContainerTab(c));
    grid.appendChild(btn);
  });
}

// ── Open container tab (normal new tab, identity carries the label name) ───
function openContainerTab(c) {
  getOrCreateIdentity(c).then(cookieStoreId => {
    browser.tabs.create({ cookieStoreId });
  }).catch(err => console.error('PwnFox+:', err));
}

// ── Modal ──────────────────────────────────────────────────────────────────
const overlay    = document.getElementById('modalOverlay');
const modalDot   = document.getElementById('modalDot');
const modalTitle = document.getElementById('modalTitle');
const labelInput = document.getElementById('labelInput');
const prevBadge  = document.getElementById('previewBadge');

function openModal(c) {
  editingColorName = c.colorName;
  modalDot.style.background = c.color;
  modalTitle.textContent = c.name + ' — label';
  labelInput.value = settings.containerLabels[c.colorName] || '';
  updatePreview();
  overlay.style.display = 'flex';
  setTimeout(() => labelInput.focus(), 50);
}

function closeModal() {
  overlay.style.display = 'none';
  editingColorName = null;
}

function updatePreview() {
  const val = labelInput.value.trim();
  const c = CONTAINERS.find(x => x.colorName === editingColorName);
  if (val && c) {
    prevBadge.style.background = c.color;
    prevBadge.style.color = BADGE_TEXT[c.colorName] || '#fff';
    prevBadge.textContent = val;
    prevBadge.style.display = 'inline-block';
  } else {
    prevBadge.style.display = 'none';
  }
}

function saveLabel() {
  if (!editingColorName) return;
  const val = labelInput.value.trim();
  const c = CONTAINERS.find(x => x.colorName === editingColorName);

  if (val) settings.containerLabels[editingColorName] = val;
  else delete settings.containerLabels[editingColorName];

  saveSettings();

  // Rename the Firefox identity so the URL bar shows the new label immediately
  if (c) applyLabelToIdentity(c, val);

  closeModal();
  renderGrid();
}

function clearLabel() {
  if (!editingColorName) return;
  const c = CONTAINERS.find(x => x.colorName === editingColorName);
  delete settings.containerLabels[editingColorName];
  saveSettings();
  if (c) applyLabelToIdentity(c, ''); // resets name back to color name
  closeModal();
  renderGrid();
}

document.getElementById('saveBtn').addEventListener('click', saveLabel);
document.getElementById('cancelBtn').addEventListener('click', closeModal);
document.getElementById('clearBtn').addEventListener('click', clearLabel);
overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
labelInput.addEventListener('input', updatePreview);
labelInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') saveLabel();
  if (e.key === 'Escape') closeModal();
});

// Footer buttons — open pages in new tabs
function openExtPage(page) {
  browser.tabs.create({ url: browser.runtime.getURL(page) });
}

document.getElementById('btn-settings').addEventListener('click', () => openExtPage('settings.html'));
document.getElementById('btn-toolbox').addEventListener('click',  () => openExtPage('toolbox.html'));
document.getElementById('btn-postmessage').addEventListener('click', () => openExtPage('postmessage.html'));

loadSettings(() => { renderToggles(); renderGrid(); });