# PwnFox+ — Complete package

## What changed

### Firefox extension (firefox-extension/)
`background.js` now sends **two** headers on every proxied request:

| Header            | Value                                      |
|-------------------|--------------------------------------------|
| `X-PwnFox-Color`  | Burp colour name (red/orange/…/magenta)    |
| `X-PwnFox-Label`  | Custom label set in the popup (if defined) |

`X-PwnFox-Label` is only added when a label has been saved for that container
colour — if no label is set the header is omitted and Burp falls back to the
colour name.

### Burp extension (burp-extension/)
`BurpExtender.java` reads both headers:
- Highlights the request with the colour from `X-PwnFox-Color`
- Sets the **Notes** column to the custom label from `X-PwnFox-Label`
  (falls back to the colour name when the label header is absent)

## Install

### Firefox extension
Load as a temporary extension: about:debugging → This Firefox → Load Temporary Add-on
→ select `firefox-extension/manifest.json`

### Burp extension
Extender → Extensions → Add → Java → select `burp-extension/pwnfox-plus-burp.jar`

## Build Burp extension from source
```bash
cd burp-extension
./build.sh
```
