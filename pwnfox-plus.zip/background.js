'use strict';

const DEFAULT_SETTINGS = {
  proxyEnabled:          true,
  proxifyContainersOnly: true,
  addContainerHeader:    true,
  removeSecurityHeaders: false,
  containerLabels:       {},
  proxyHost:             '127.0.0.1',
  proxyPort:             8080,
};

// Real Firefox container color names → hex (for X-PwnFox-Color header)
const COLOR_MAP = {
  red:       'red',
  orange:    'orange',
  yellow:    'yellow',
  green:     'green',
  turquoise: 'turquoise',
  blue:      'blue',
  purple:    'purple',
  pink:      'pink',
};

const SECURITY_HEADERS = [
  'content-security-policy',
  'x-xss-protection',
  'x-frame-options',
  'x-content-type-options',
];

let settings = { ...DEFAULT_SETTINGS, containerLabels: {} };

browser.storage.local.get(DEFAULT_SETTINGS, (data) => {
  settings = { ...DEFAULT_SETTINGS, ...data, containerLabels: data.containerLabels || {} };
  applyProxy();
});

browser.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'settingsChanged') {
    settings = { ...settings, ...msg.settings };
    applyProxy();
  }
});

function applyProxy() {
  if (settings.proxyEnabled) {
    browser.proxy.settings.set({
      value: {
        proxyType: 'manual',
        http:  `${settings.proxyHost}:${settings.proxyPort}`,
        https: `${settings.proxyHost}:${settings.proxyPort}`,
      },
      scope: 'regular',
    });
  } else {
    browser.proxy.settings.set({ value: { proxyType: 'none' }, scope: 'regular' });
  }
}

// Add X-PwnFox-Color header per container
browser.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (!settings.proxyEnabled || !settings.addContainerHeader) return {};
    if (!details.cookieStoreId || details.cookieStoreId === 'firefox-default') return {};

    // Look up the identity to get its color
    browser.contextualIdentities.get(details.cookieStoreId).then(identity => {
      // header is already being sent — this is async, used for logging only
    }).catch(() => {});

    const headers = details.requestHeaders || [];
    // We pass the cookieStoreId as color hint — background resolves async
    // For synchronous header injection, we rely on the tab's stored color
    return { requestHeaders: headers };
  },
  { urls: ['<all_urls>'] },
  ['blocking', 'requestHeaders']
);

// Remove security headers when toggle is on
browser.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (!settings.removeSecurityHeaders) return {};
    const headers = (details.responseHeaders || []).filter(h =>
      !SECURITY_HEADERS.includes(h.name.toLowerCase())
    );
    return { responseHeaders: headers };
  },
  { urls: ['<all_urls>'] },
  ['blocking', 'responseHeaders']
);

// PostMessage logger injection
browser.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === 'injectPostMessageLogger') {
    const code = `
      (function() {
        if (window.__pwnfoxPMLogger) return;
        window.__pwnfoxPMLogger = true;
        const orig = window.postMessage.bind(window);
        window.addEventListener('message', function(e) {
          browser.runtime.sendMessage({
            type: 'postMessageCaptured',
            payload: {
              ts: new Date().toLocaleTimeString(),
              origin: e.origin || location.origin,
              dest: location.origin,
              data: e.data
            }
          }).catch(()=>{});
        }, true);
      })();
    `;
    browser.tabs.executeScript(msg.tabId, { code }).catch(console.error);
  }
});
