'use strict';

const DEFAULT_SETTINGS = {
  proxyEnabled:          true,
  proxifyContainersOnly: true,
  addContainerHeader:    true,
  removeSecurityHeaders: false,
  containerLabels:       {},
  proxyHost:             '127.0.0.1',
  proxyPort:             8080,
};

const SECURITY_HEADERS = [
  'content-security-policy',
  'x-xss-protection',
  'x-frame-options',
  'x-content-type-options',
];

// ── Color map: cookieStoreId → colorName (kept in sync synchronously) ──────
// This is the key fix — onBeforeSendHeaders is SYNCHRONOUS/blocking,
// so we cannot call contextualIdentities.get() (async) inside it.
// We pre-build this map at startup and keep it updated via events.
const containerColorMap = {};

// Burp PwnFox JAR only recognises these 8 values exactly:
// red, orange, yellow, green, cyan, blue, magenta, pink
// Firefox uses 'turquoise' and 'purple' — map them to Burp equivalents
const FIREFOX_TO_BURP_COLOR = {
  red:       'red',
  orange:    'orange',
  yellow:    'yellow',
  green:     'green',
  turquoise: 'cyan',      // Firefox=turquoise  →  Burp=cyan
  blue:      'blue',
  purple:    'magenta',   // Firefox=purple     →  Burp=magenta
  pink:      'pink',
};

function buildColorMap() {
  browser.contextualIdentities.query({}).then(identities => {
    for (const id of identities) {
      containerColorMap[id.cookieStoreId] = id.color;
    }
  }).catch(() => {});
}

// Keep map in sync when containers are created/updated/removed
browser.contextualIdentities.onCreated.addListener(({ contextualIdentity: id }) => {
  containerColorMap[id.cookieStoreId] = id.color;
});
browser.contextualIdentities.onUpdated.addListener(({ contextualIdentity: id }) => {
  containerColorMap[id.cookieStoreId] = id.color;
});
browser.contextualIdentities.onRemoved.addListener(({ contextualIdentity: id }) => {
  delete containerColorMap[id.cookieStoreId];
});

// ── Settings ───────────────────────────────────────────────────────────────
let settings = { ...DEFAULT_SETTINGS, containerLabels: {} };

browser.storage.local.get(DEFAULT_SETTINGS, (data) => {
  settings = { ...DEFAULT_SETTINGS, ...data, containerLabels: data.containerLabels || {} };
  buildColorMap();
  applyProxy();
});

browser.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'settingsChanged') {
    settings = { ...settings, ...msg.settings };
    applyProxy();
  }
  if (msg.type === 'injectPostMessageLogger') {
    const code = `
      (function() {
        if (window.__pwnfoxPMLogger) return;
        window.__pwnfoxPMLogger = true;
        window.addEventListener('message', function(e) {
          browser.runtime.sendMessage({
            type: 'postMessageCaptured',
            payload: {
              ts: new Date().toLocaleTimeString(),
              origin: e.origin || location.origin,
              dest: location.origin,
              data: e.data
            }
          }).catch(()=>{});
        }, true);
      })();
    `;
    browser.tabs.executeScript(msg.tabId, { code }).catch(console.error);
  }
});

// ── Proxy ──────────────────────────────────────────────────────────────────
function applyProxy() {
  if (settings.proxyEnabled) {
    browser.proxy.settings.set({
      value: {
        proxyType: 'manual',
        http:  `${settings.proxyHost}:${settings.proxyPort}`,
        https: `${settings.proxyHost}:${settings.proxyPort}`,
        socks: '',
        passthrough: 'localhost, 127.0.0.1',
      },
      scope: 'regular',
    });
  } else {
    browser.proxy.settings.set({ value: { proxyType: 'none' }, scope: 'regular' });
  }
}

// ── Add X-PwnFox-Color header (SYNCHRONOUS — uses pre-built map) ───────────
// The Burp PwnFox extension expects exactly this header name and the Firefox
// color name as value: red, orange, yellow, green, turquoise, blue, purple, pink
browser.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (!settings.addContainerHeader) return {};
    if (!details.cookieStoreId || details.cookieStoreId === 'firefox-default') return {};

    const firefoxColor = containerColorMap[details.cookieStoreId];
    if (!firefoxColor) return {};
    const color = FIREFOX_TO_BURP_COLOR[firefoxColor] || firefoxColor;

    const headers = (details.requestHeaders || [])
      .filter(h => h.name.toLowerCase() !== 'x-pwnfox-color');

    headers.push({ name: 'X-PwnFox-Color', value: color });

    return { requestHeaders: headers };
  },
  { urls: ['<all_urls>'] },
  ['blocking', 'requestHeaders']
);

// ── Remove security headers ────────────────────────────────────────────────
browser.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (!settings.removeSecurityHeaders) return {};
    const headers = (details.responseHeaders || []).filter(h =>
      !SECURITY_HEADERS.includes(h.name.toLowerCase())
    );
    return { responseHeaders: headers };
  },
  { urls: ['<all_urls>'] },
  ['blocking', 'responseHeaders']
);
