package burp;
import java.io.OutputStream;
public interface IBurpExtenderCallbacks {
    void setExtensionName(String name);
    void registerHttpListener(IHttpListener listener);
    void registerProxyListener(IProxyListener listener);
    IHttpRequestResponse[] getProxyHistory();
    void printOutput(String output);
    void printError(String error);
    OutputStream getStdout();
    OutputStream getStderr();
    IExtensionHelpers getHelpers();
    void addSuiteTab(ITab tab);
    String getExtensionFilename();
    boolean isExtensionBapp();
}
