#!/bin/bash
# Build script for PwnFox+ Burp Extension
mkdir -p out
find src -name "*.java" > sources.txt
javac -d out $(cat sources.txt)
jar cf pwnfox-plus-burp.jar -C out .
echo "Built: pwnfox-plus-burp.jar"
rm -f sources.txt
