package burp;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

/**
 * PwnFox+ Burp Extension
 *
 * Reads the X-PwnFox-Color header injected by the PwnFox+ Firefox extension
 * and highlights requests in Burp's Proxy history with the matching colour.
 *
 * Colour mapping (Firefox → Burp highlight string):
 *   red       → red
 *   orange    → orange
 *   yellow    → yellow
 *   green     → green
 *   turquoise → cyan     (mapped by the browser ext before sending)
 *   blue      → blue
 *   purple    → magenta  (mapped by the browser ext before sending)
 *   pink      → pink
 */
public class BurpExtender implements IBurpExtender, IProxyListener, IHttpListener, ITab {

    private static final String HEADER_COLOR = "X-PwnFox-Color";
    private static final String HEADER_LABEL = "X-PwnFox-Label";
    private static final String EXTENSION_NAME = "PwnFox+";

    /**
     * Maps the value of X-PwnFox-Color to the exact string Burp Suite
     * expects for setHighlight().
     * Burp accepts: red, orange, yellow, green, cyan, blue, magenta, pink, gray, white
     */
    private static final Map<String, String> COLOR_MAP = new HashMap<>();
    static {
        COLOR_MAP.put("red",      "red");
        COLOR_MAP.put("orange",   "orange");
        COLOR_MAP.put("yellow",   "yellow");
        COLOR_MAP.put("green",    "green");
        COLOR_MAP.put("cyan",     "cyan");      // already mapped by browser ext (turquoise→cyan)
        COLOR_MAP.put("blue",     "blue");
        COLOR_MAP.put("magenta",  "magenta");   // already mapped by browser ext (purple→magenta)
        COLOR_MAP.put("pink",     "pink");
        // defensive fallbacks in case raw Firefox colour names arrive
        COLOR_MAP.put("turquoise", "cyan");
        COLOR_MAP.put("purple",    "magenta");
    }

    private IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;

    // UI
    private JPanel uiPanel;
    private JLabel statsLabel;
    private int totalTagged = 0;

    // ── IBurpExtender ────────────────────────────────────────────────────────

    @Override
    public void registerExtenderCallbacks(IBurpExtenderCallbacks callbacks) {
        this.callbacks = callbacks;
        this.helpers   = callbacks.getHelpers();

        callbacks.setExtensionName(EXTENSION_NAME);

        // Listen on the proxy (highlights appear in Proxy > HTTP history)
        callbacks.registerProxyListener(this);
        // Also listen on all other Burp tools so repeater/scanner etc. get tagged
        callbacks.registerHttpListener(this);

        buildUi();
        callbacks.addSuiteTab(this);

        callbacks.printOutput("[PwnFox+] Extension loaded — watching for " + HEADER_COLOR + " / " + HEADER_LABEL + " headers.");
    }

    // ── IProxyListener ───────────────────────────────────────────────────────

    @Override
    public void processProxyMessage(boolean messageIsRequest, IInterceptedProxyMessage message) {
        if (!messageIsRequest) return;
        applyHighlight(message.getMessageInfo());
    }

    // ── IHttpListener ────────────────────────────────────────────────────────

    @Override
    public void processHttpMessage(int toolFlag, boolean messageIsRequest, IHttpRequestResponse messageInfo) {
        if (!messageIsRequest) return;
        applyHighlight(messageInfo);
    }

    // ── Core logic ───────────────────────────────────────────────────────────

    private void applyHighlight(IHttpRequestResponse messageInfo) {
        try {
            byte[] request = messageInfo.getRequest();
            if (request == null) return;

            IRequestInfo reqInfo = helpers.analyzeRequest(request);
            List<String> headers = reqInfo.getHeaders();

            String colorValue = null;
            String labelValue = null;

            for (String header : headers) {
                String lower = header.toLowerCase();
                if (lower.startsWith(HEADER_COLOR.toLowerCase() + ":")) {
                    colorValue = header.substring(header.indexOf(':') + 1).trim().toLowerCase();
                }
                if (lower.startsWith(HEADER_LABEL.toLowerCase() + ":")) {
                    labelValue = header.substring(header.indexOf(':') + 1).trim();
                }
            }

            if (colorValue == null) return;

            String burpColor = COLOR_MAP.get(colorValue);
            if (burpColor == null) {
                callbacks.printOutput("[PwnFox+] Unknown colour value: " + colorValue + " — skipping highlight.");
                return;
            }

            messageInfo.setHighlight(burpColor);

            // Use the custom label if defined, otherwise fall back to the colour name
            String tag = (labelValue != null && !labelValue.isEmpty()) ? labelValue : colorValue;

            String existing = messageInfo.getComment();
            if (existing == null || existing.isEmpty()) {
                messageInfo.setComment(tag);
            } else if (!existing.contains(tag)) {
                messageInfo.setComment(existing + " | " + tag);
            }

            // Update stats counter in UI
            totalTagged++;
            SwingUtilities.invokeLater(() ->
                statsLabel.setText("Requests tagged: " + totalTagged));

        } catch (Exception e) {
            callbacks.printError("[PwnFox+] Error in applyHighlight: " + e.getMessage());
        }
    }

    // ── ITab (settings/info panel) ───────────────────────────────────────────

    private void buildUi() {
        uiPanel = new JPanel(new BorderLayout(10, 10));
        uiPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Title
        JLabel title = new JLabel(EXTENSION_NAME + " — Container Colour Highlighter");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));
        uiPanel.add(title, BorderLayout.NORTH);

        // Centre: colour reference table
        String[] cols = {"Firefox container colour", "Burp highlight colour", "Sample"};
        Object[][] rows = {
            {"red",       "red",     ""},
            {"orange",    "orange",  ""},
            {"yellow",    "yellow",  ""},
            {"green",     "green",   ""},
            {"turquoise", "cyan",    "(Firefox) → cyan in Burp"},
            {"blue",      "blue",    ""},
            {"purple",    "magenta", "(Firefox) → magenta in Burp"},
            {"pink",      "pink",    ""},
        };
        DefaultTableModel model = new DefaultTableModel(rows, cols) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        table.setFillsViewportHeight(true);
        table.getColumnModel().getColumn(0).setPreferredWidth(200);
        table.getColumnModel().getColumn(1).setPreferredWidth(200);
        table.getColumnModel().getColumn(2).setPreferredWidth(250);
        uiPanel.add(new JScrollPane(table), BorderLayout.CENTER);

        // South: stats
        JPanel south = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statsLabel = new JLabel("Requests tagged: 0");
        south.add(statsLabel);

        JLabel info = new JLabel(
            "  |  Reads X-PwnFox-Color header — set by the PwnFox+ Firefox extension");
        info.setForeground(Color.GRAY);
        south.add(info);
        uiPanel.add(south, BorderLayout.SOUTH);
    }

    @Override
    public String getTabCaption() { return EXTENSION_NAME; }

    @Override
    public Component getUiComponent() { return uiPanel; }
}
