package burp;
public interface IInterceptedProxyMessage {
    IHttpRequestResponse getMessageInfo();
    int getMessageReference();
    String getListenerInterface();
    java.net.InetAddress getClientIpAddress();
}
