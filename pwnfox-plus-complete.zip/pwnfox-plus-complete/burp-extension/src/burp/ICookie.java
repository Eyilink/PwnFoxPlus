package burp;
import java.util.Date;
public interface ICookie {
    String getDomain();
    Date getExpiration();
    String getName();
    String getValue();
    String getPath();
}
